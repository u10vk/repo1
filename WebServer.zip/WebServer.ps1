﻿Configuration IISWebsiteConf {
    param(    
        [string]$NodeName,
    
        [Parameter(Mandatory=$true)]
        [ValidateNotNullorEmpty()] 
        [System.Management.Automation.PSCredential]
        $storageCredential
    );

    Import-DscResource -ModuleName PSDesiredStateConfiguration;

    ### $storageCredential = Get-AutomationPSCredential -Name "PackageStorage"

    $webServerFeats = @(   "Web-Server", 
                        "Web-WebServer", 
                        "Web-Common-Http", 
                        "Web-Default-Doc", 
                        "Web-Http-Errors", 
                        "Web-Static-Content", 
                        "Web-Http-Redirect", 
                        "Web-Health", 
                        "Web-Http-Logging", 
                        "Web-Log-Libraries", 
                        "Web-ODBC-Logging", 
                        "Web-Request-Monitor", 
                        "Web-Http-Tracing", 
                        "Web-Performance", 
                        "Web-Stat-Compression", 
                        "Web-Dyn-Compression", 
                        "Web-Security", 
                        "Web-Filtering", 
                        "Web-Basic-Auth", 
                        "Web-CertProvider", 
                        "Web-Client-Auth", 
                        "Web-Digest-Auth", 
                        "Web-Cert-Auth", 
                        "Web-IP-Security", 
                        "Web-Url-Auth", 
                        "Web-App-Dev", 
                        "Web-Net-Ext", 
                        "Web-Net-Ext45", 
                        "Web-Asp-Net", 
                        "Web-Asp-Net45", 
                        "Web-ISAPI-Ext", 
                        "Web-ISAPI-Filter", 
                        "Web-Mgmt-Tools", 
                        "Web-Mgmt-Console", 
                        "Web-Mgmt-Service" );
    
    
    Node $NodeName {

        $webServerFeats.ForEach({
            WindowsFeature $_ {
                Ensure = "Present";
                Name = $_
            }
        })

        # Install IIS URLRewrite Module
        # https://download.microsoft.com/download/1/2/8/128E2E22-C1B9-44A4-BE2A-5859ED1D4592/rewrite_amd64_en-US.msi
        # Check for ProductID: Get-WmiObject Win32_Product | Format-Table IdentifyingNumber, Name, Version
        Package UrlRewrite
		{
			DependsOn = "[WindowsFeature]Web-Server"
			Ensure = "Present"
			Name = "IIS URL Rewrite Module 2"
			Path = "https://download.microsoft.com/download/1/2/8/128E2E22-C1B9-44A4-BE2A-5859ED1D4592/rewrite_amd64_en-US.msi"
			Arguments = "/quiet LicenseAccepted='0' ADDLOCAL=ALL"
			ProductId = "9BCA2118-F753-4A1E-BCF3-5A820729965C"
		}
        Package WebDeploy
		{
			DependsOn = "[WindowsFeature]Web-Server"
			Ensure = "Present"
			Name = "Microsoft Web Deploy 3.6"
			Path = "https://download.microsoft.com/download/0/1/D/01DC28EA-638C-4A22-A57B-4CEF97755C6C/WebDeploy_amd64_en-US.msi"
			Arguments = "/quiet LicenseAccepted='0' ADDLOCAL=ALL"
			ProductId = "6773A61D-755B-4F74-95CC-97920E45E696"
		}

        Service WMSVC {
            Name        = "TermService"
            StartupType = "Automatic"
            State       = "Running"
        }


        File SiteRootDownload
        {
            DestinationPath = "C:\Temp"
            ### Credential = $storageCredential
            Ensure = "Present"
            SourcePath = "https:\\foxtrotdatastor01.file.core.windows.net\deploy\foxtrot.com.ua.zip"
            Type = "File"
            Force = $true
        }

        Archive Unzip {
            Path = "C:\Temp\foxtrot.com.ua.zip";
            Destination = "C:\intepub\wwwroot\DefaultWebsite"
            Ensure = "Present"
            Force = "True"
        }

    }

}

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName="*";
            PSDscAllowPlainTextPassword=$true;
            PSDscAllowDomainUser = $true;
         }
    )
}



#IISWebsiteConf -nodeName "server01" -ConfigurationData $ConfigurationData;

###
# Set-AzureVMDscExtension -VM $vm -ConfigurationArchive MyConfiguration.ps1.zip -ConfigurationName MyConfiguration -ConfigurationArgument @{ storageCredential= (Get-Credential) }
###